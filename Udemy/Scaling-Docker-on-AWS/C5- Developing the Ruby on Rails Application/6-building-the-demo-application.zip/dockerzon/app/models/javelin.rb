class Javelin < ActiveRecord::Base
end
