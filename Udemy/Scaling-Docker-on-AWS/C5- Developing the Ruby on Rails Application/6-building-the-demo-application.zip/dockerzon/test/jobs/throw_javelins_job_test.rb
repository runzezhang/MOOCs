require 'test_helper'

class ThrowJavelinsJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
