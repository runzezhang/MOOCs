Rack::Timeout.timeout = Integer(ENV['REQUEST_TIMEOUT'] || 5)
